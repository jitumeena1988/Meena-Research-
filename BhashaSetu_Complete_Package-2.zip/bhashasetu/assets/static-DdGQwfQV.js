import"./main-DGBGpf5w.js";/* empty css              */
